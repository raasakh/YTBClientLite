(function() {
    'use strict';

    angular.module('app.dex', ['app.shared', 'ngSanitize']);
})();
