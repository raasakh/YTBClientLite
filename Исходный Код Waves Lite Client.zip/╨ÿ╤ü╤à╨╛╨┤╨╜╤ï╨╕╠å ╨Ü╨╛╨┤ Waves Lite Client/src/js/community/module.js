(function() {
    'use strict';

    angular.module('app.community', ['app.shared']);
})();
