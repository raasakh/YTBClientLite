(function() {
    'use strict';

    angular.module('app.login', ['waves.core.services', 'app.ui', 'app.shared']);
})();
