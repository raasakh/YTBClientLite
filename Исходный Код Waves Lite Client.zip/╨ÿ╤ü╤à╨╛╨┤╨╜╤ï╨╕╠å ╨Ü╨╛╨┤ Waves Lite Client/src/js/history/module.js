(function() {
    'use strict';

    angular.module('app.history', ['app.shared']);
})();
