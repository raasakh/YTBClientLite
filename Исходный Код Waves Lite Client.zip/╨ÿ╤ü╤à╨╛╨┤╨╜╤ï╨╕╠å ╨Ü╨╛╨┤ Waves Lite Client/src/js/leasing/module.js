(function() {
    'use strict';

    angular.module('app.leasing', ['app.shared']);
})();
