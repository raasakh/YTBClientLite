(function() {
    'use strict';

    angular.module('app.tokens', ['app.shared']);
})();
